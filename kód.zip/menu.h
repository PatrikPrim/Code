#ifndef UNTITLED_MENU_H
#define UNTITLED_MENU_H
#include <iostream>
#include <string>
#include "phonebook.h"
#include "contact.h"
#include "name.h"
#include "memtrace.h"



namespace menu {
    void lista();
    void vegrehajt(int pont, Phonebook* phonebook);
    void fomenu();
}

#endif //UNTITLED_MENU_H
